import Main

Main.MainEntryPoint()